CREATE DATABASE ENERGYDB2;
USE ENERGYDB2;

SELECT * FROM country;
SELECT * FROM consumption;
SELECT * FROM production;
SELECT * FROM emission;
SELECT * FROM population;
SELECT * FROM gdp;

DESC country;
DESC consumption;
DESC production;
DESC emission;
DESC population;
DESC gdp;

ALTER TABLE emission
MODIFY emission DOUBLE;

ALTER TABLE population
MODIFY Value BIGINT;

ALTER TABLE gdp
MODIFY Value DOUBLE;

SHOW KEYS FROM country;

ALTER TABLE country
MODIFY Country VARCHAR(100);

ALTER TABLE country
ADD PRIMARY KEY (Country);

ALTER TABLE consumption
MODIFY country VARCHAR(100);

ALTER TABLE consumption
ADD CONSTRAINT fk_consumption_country
FOREIGN KEY (country)
REFERENCES country(Country);

ALTER TABLE production
MODIFY country VARCHAR(100);

ALTER TABLE production
ADD CONSTRAINT fk_production_country
FOREIGN KEY (country)
REFERENCES country(Country);

ALTER TABLE emission
MODIFY country VARCHAR(100);

ALTER TABLE emission
ADD CONSTRAINT fk_emission_country
FOREIGN KEY (country)
REFERENCES country(Country);

ALTER TABLE population
MODIFY countries VARCHAR(100);

ALTER TABLE population
ADD CONSTRAINT fk_population_country
FOREIGN KEY (countries)
REFERENCES country(Country);

ALTER TABLE gdp
MODIFY Country VARCHAR(100);

ALTER TABLE gdp
ADD CONSTRAINT fk_gdp_country
FOREIGN KEY (Country)
REFERENCES country(Country);


-- General & Comparative Analysis
-- 1. What is the total emission per country for the most recent year available?
SELECT country,
       SUM(emission) AS total_emission
FROM emission
WHERE year = (SELECT MAX(year) FROM emission)
GROUP BY country
ORDER BY total_emission DESC;

-- 2. What are the top 5 countries by GDP in the most recent year?
SELECT Country,
       Value AS GDP
FROM gdp
WHERE year = (SELECT MAX(year) FROM gdp)
ORDER BY GDP DESC
LIMIT 5;

-- 3. Compare energy production and consumption by country and year.
SELECT p.country,
       p.year,
       SUM(p.production) AS total_production,
       SUM(c.consumption) AS total_consumption
FROM production p
JOIN consumption c
ON p.country = c.country AND p.year = c.year
GROUP BY p.country, p.year;

-- 4. Which energy types contribute most to emissions across all countries?
SELECT `energy type`,
       SUM(emission) AS total_emission
FROM emission
GROUP BY `energy type`
ORDER BY total_emission DESC;

DESC emission;

-- Trend Analysis Over Time
-- 5. How have global emissions changed year over year? 
SELECT year,
       SUM(emission) AS global_emission
FROM emission
GROUP BY year
ORDER BY year;

-- 6. What is the trend in GDP for each country over the given years? 
SELECT Country,
       year,
       Value AS GDP
FROM gdp
ORDER BY Country, year;

-- 7. How has population growth affected total emissions in each country? 
SELECT e.country,
       e.year,
       SUM(e.emission) / MAX(p.Value) AS emission_per_capita
FROM emission e
JOIN population p
ON e.country = p.countries
AND e.year = p.year
GROUP BY e.country, e.year;

-- 8. Has energy consumption increased or decreased over the years for major economies?
SELECT c.country,
       c.year,
       SUM(c.consumption) AS total_consumption
FROM consumption c
WHERE c.country IN ('United States', 'China', 'India', 'Germany', 'Japan')
GROUP BY c.country, c.year
ORDER BY c.country, c.year;

-- 9. What is the average yearly change in emissions per capita for each country? 
WITH per_capita AS (
    SELECT 
        e.country,
        e.year,
        SUM(e.emission) / MAX(p.Value) AS emission_per_capita
    FROM emission e
    JOIN population p
        ON e.country = p.countries
       AND e.year = p.year
    GROUP BY e.country, e.year
),
yearly_change AS (
    SELECT
        country,
        year,
        emission_per_capita,
        emission_per_capita 
        - LAG(emission_per_capita) OVER (PARTITION BY country ORDER BY year) 
        AS yearly_change
    FROM per_capita
)
SELECT
    country,
    AVG(yearly_change) AS avg_yearly_change_emission_per_capita
FROM yearly_change
WHERE yearly_change IS NOT NULL
GROUP BY country
ORDER BY avg_yearly_change_emission_per_capita DESC;

-- Ratio & Per Capita Analysis 
-- 10. What is the emission-to-GDP ratio for each country by year?
SELECT 
    e.country,
    e.year,
    SUM(e.emission) / MAX(g.Value) AS emission_to_gdp_ratio
FROM emission e
JOIN gdp g
ON e.country = g.Country AND e.year = g.year
GROUP BY e.country, e.year;

-- 11. What is the energy consumption per capita for each country over the last decade?
SELECT 
    c.country,
    c.year,
    SUM(c.consumption) / MAX(p.Value) AS consumption_per_capita
FROM consumption c
JOIN population p
ON c.country = p.countries
AND c.year = p.year
WHERE c.year >= (SELECT MAX(year) - 9 FROM consumption)
GROUP BY c.country, c.year
ORDER BY c.country, c.year;

-- 12. How does energy production per capita vary across countries?
SELECT 
    pr.country,
    pr.year,
    SUM(pr.production) / MAX(p.Value) AS production_per_capita
FROM production pr
JOIN population p
ON pr.country = p.countries
AND pr.year = p.year
WHERE pr.year = (SELECT MAX(year) FROM production)
GROUP BY pr.country, pr.year
ORDER BY production_per_capita DESC;

-- 13. Which countries have the highest energy consumption relative to GDP? 
SELECT 
    c.country,
    SUM(c.consumption) / MAX(g.Value) AS consumption_to_gdp_ratio
FROM consumption c
JOIN gdp g
ON c.country = g.Country
AND c.year = g.year
WHERE c.year = (SELECT MAX(year) FROM consumption)
GROUP BY c.country
ORDER BY consumption_to_gdp_ratio DESC;

-- 14. What is the correlation between GDP growth and energy production growth?
SELECT 
    g.country,
    g.year,
    (g.Value - LAG(g.Value) OVER (PARTITION BY g.Country ORDER BY g.year)) AS gdp_growth,
    (SUM(p.production) 
     - LAG(SUM(p.production)) OVER (PARTITION BY p.country ORDER BY p.year)
    ) AS production_growth
FROM gdp g
JOIN production p
ON g.Country = p.country
AND g.year = p.year
GROUP BY g.country, g.year, g.Value;

-- Global Comparisons 
-- 15. What are the top 10 countries by population and how do their emissions compare?
SELECT p.countries,
       p.Value AS population,
       SUM(e.emission) AS total_emission
FROM population p
JOIN emission e
ON p.countries = e.country 
AND p.year = e.year
WHERE p.year = (
    SELECT MIN(max_year)
    FROM (
        SELECT MAX(year) AS max_year FROM population
        UNION
        SELECT MAX(year) AS max_year FROM emission
    ) t
)
GROUP BY p.countries, p.Value
ORDER BY population DESC
LIMIT 10;


-- 16. Which countries have improved (reduced) their per capita emissions the most over the last decade?
SELECT 
    e.country,
    ( 
      (SUM(CASE WHEN e.year = y.start_year THEN e.emission END) / MAX(CASE WHEN e.year = y.start_year THEN p.Value END))
      -
      (SUM(CASE WHEN e.year = y.end_year THEN e.emission END) / MAX(CASE WHEN e.year = y.end_year THEN p.Value END))
    ) AS reduction_in_emission_per_capita
FROM emission e
JOIN population p
ON e.country = p.countries AND e.year = p.year
JOIN (
    SELECT 
        MAX(year) AS end_year,
        MAX(year) - 9 AS start_year
    FROM emission
) y
GROUP BY e.country
ORDER BY reduction_in_emission_per_capita DESC;

SELECT MIN(year), MAX(year) FROM emission;
SELECT MIN(year), MAX(year) FROM population;

SELECT 
    e.country,
    (
        (SUM(CASE WHEN e.year = t.start_year THEN e.emission END) / MAX(CASE WHEN e.year = t.start_year THEN p.Value END))
        -
        (SUM(CASE WHEN e.year = t.end_year THEN e.emission END) / MAX(CASE WHEN e.year = t.end_year THEN p.Value END))
    ) AS reduction_in_emission_per_capita
FROM emission e
JOIN population p
ON e.country = p.countries AND e.year = p.year
JOIN (
    SELECT 
        country,
        MIN(year) AS start_year,
        MAX(year) AS end_year
    FROM emission
    WHERE year >= (SELECT MAX(year) - 9 FROM emission)
    GROUP BY country
) t
ON e.country = t.country
GROUP BY e.country
HAVING reduction_in_emission_per_capita IS NOT NULL
ORDER BY reduction_in_emission_per_capita DESC;

-- 17. What is the global share (%) of emissions by country? 
SELECT 
    country,
    (SUM(emission) * 100.0 / 
     (SELECT SUM(emission) 
      FROM emission 
      WHERE year = (SELECT MAX(year) FROM emission))
    ) AS emission_share_percent
FROM emission
WHERE year = (SELECT MAX(year) FROM emission)
GROUP BY country
ORDER BY emission_share_percent DESC;

-- 18. What is the global average GDP, emission, and population by year?
SELECT 
    e.year,
    AVG(g.Value) AS avg_gdp,
    AVG(e.emission) AS avg_emission,
    AVG(p.Value) AS avg_population
FROM emission e
JOIN gdp g
ON e.country = g.Country AND e.year = g.year
JOIN population p
ON e.country = p.countries AND e.year = p.year
GROUP BY e.year
ORDER BY e.year;


















